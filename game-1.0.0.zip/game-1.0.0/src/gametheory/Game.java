package gametheory;



import java.util.Arrays;
import java.util.List;

public class Game {
    private Strategy player1Strategy;
    private Strategy player2Strategy;

    public Game(Strategy player1Strategy, Strategy player2Strategy) {
        this.player1Strategy = player1Strategy;
        this.player2Strategy = player2Strategy;
    }

    // Method to execute the game for a given number of rounds
    public List<Integer> executeGame(int rounds) {
        int player1Score = 0;
        int player2Score = 0;

        for (int i = 0; i < rounds; i++) {
            boolean player1Move = player1Strategy.makeMove();
            boolean player2Move = player2Strategy.makeMove();

            // Scoring system:
            if (player1Move && player2Move) {
                player1Score += 3; // Both cooperate
                player2Score += 3;
            } else if (player1Move && !player2Move) {
                player1Score += 0; // Player 1 cooperates, Player 2 defects
                player2Score += 5;
            } else if (!player1Move && player2Move) {
                player1Score += 5; // Player 1 defects, Player 2 cooperates
                player2Score += 0;
            } else {
                player1Score += 1; // Both defect
                player2Score += 1;
            }

            // Update strategies with the opponent's move for future rounds
            player1Strategy.addOpponentMove(player2Move);
            player2Strategy.addOpponentMove(player1Move);
        }

        // Return the scores for both players
        return Arrays.asList(player1Score, player2Score);
    }
}
