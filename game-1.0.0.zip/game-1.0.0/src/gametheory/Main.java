package gametheory;

import gametheory.strategiesImpl.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        // List of all strategies
        List<Strategy> allStrategies = Arrays.asList(
                new AlwaysCooperate(),
                new AlwaysDefect(),
                new GeneticMemory(),
                new GeneticOneMove(),
                new GeneticStrategy(0.5), // Example with 0.5 parameter for GeneticStrategy
                new Grudger(),
                new Simpleton()
        );

        // Display all strategies
        System.out.println("Available strategies:");
        for (int i = 0; i < allStrategies.size(); i++) {
            System.out.println((i + 1) + ". " + allStrategies.get(i).getStrategyName());
        }

        // Get user input to assign 3 strategies to Player 1
        Scanner scanner = new Scanner(System.in);
        Set<Strategy> player1Strategies = new HashSet<>();
        System.out.println("\nAssign 3 strategies to Player 1 from the above list:");
        while (player1Strategies.size() < 3) {
            System.out.print("Enter the number for Player 1's strategy: ");
            int choice = scanner.nextInt();
            if (choice < 1 || choice > allStrategies.size()) {
                System.out.println("Invalid input. Please select a valid strategy number.");
            } else {
                // Check if strategy has already been assigned to Player 1
                player1Strategies.add(allStrategies.get(choice - 1));
            }
        }

        // Get user input to assign 3 strategies to Player 2
        Set<Strategy> player2Strategies = new HashSet<>();
        System.out.println("\nAssign 3 strategies to Player 2 from the above list (excluding Player 1's choices):");
        while (player2Strategies.size() < 3) {
            System.out.print("Enter the number for Player 2's strategy: ");
            int choice = scanner.nextInt();
            if (choice < 1 || choice > allStrategies.size()) {
                System.out.println("Invalid input. Please select a valid strategy number.");
            } else {
                Strategy selectedStrategy = allStrategies.get(choice - 1);
                // Check if the strategy is already assigned to Player 1
                if (!player1Strategies.contains(selectedStrategy)) {
                    player2Strategies.add(selectedStrategy);
                } else {
                    System.out.println("This strategy has already been assigned to Player 1. Please select another.");
                }
            }
        }

        // Display strategies for Player 1 and Player 2
        System.out.println("\nPlayer 1's assigned strategies:");
        player1Strategies.forEach(strategy -> System.out.println(strategy.getStrategyName()));

        System.out.println("\nPlayer 2's assigned strategies:");
        player2Strategies.forEach(strategy -> System.out.println(strategy.getStrategyName()));

        // Ask user for the number of rounds they want to play
        System.out.print("\nEnter the number of rounds you want to play: ");
        int rounds = scanner.nextInt();  // Get the number of rounds from user input

        int currentRound = 1;

        // Game loop for the selected number of rounds
        while (currentRound <= rounds) {
            System.out.println("\nRound " + currentRound);

            // Display available strategies for Player 1
            System.out.println("Available strategies for Player 1:");
            List<Strategy> player1List = new ArrayList<>(player1Strategies);
            for (int i = 0; i < player1List.size(); i++) {
                System.out.println((i + 1) + ". " + player1List.get(i).getStrategyName());
            }

            // Get user input for Player 1's strategy
            System.out.print("Enter the number for Player 1's strategy: ");
            int player1Choice = scanner.nextInt();
            if (player1Choice < 1 || player1Choice > player1List.size()) {
                System.out.println("Invalid input for Player 1's strategy.");
                return;
            }

            Strategy player1Strategy = player1List.get(player1Choice - 1);

            // Display available strategies for Player 2
            System.out.println("Available strategies for Player 2:");
            List<Strategy> player2List = new ArrayList<>(player2Strategies);
            for (int i = 0; i < player2List.size(); i++) {
                System.out.println((i + 1) + ". " + player2List.get(i).getStrategyName());
            }

            // Get user input for Player 2's strategy
            System.out.print("Enter the number for Player 2's strategy: ");
            int player2Choice = scanner.nextInt();
            if (player2Choice < 1 || player2Choice > player2List.size()) {
                System.out.println("Invalid input for Player 2's strategy.");
                return;
            }

            Strategy player2Strategy = player2List.get(player2Choice - 1);

            // Display the chosen strategies
            System.out.println("Player 1 chose: " + player1Strategy.getStrategyName());
            System.out.println("Player 2 chose: " + player2Strategy.getStrategyName());

            // Create the game with the selected strategies
            Game game = new Game(player1Strategy, player2Strategy);

            // Execute the game for this round
            List<Integer> results = game.executeGame(1); // Execute for 1 round

            // Print the results: Player 1's score and Player 2's score
            System.out.println("Game Results: ");
            System.out.println("Player 1's score = " + results.get(0));
            System.out.println("Player 2's score = " + results.get(1));

            // Increment the round counter
            currentRound++;
        }
    }
}
