package gametheory;


import java.util.ArrayList;
import java.util.List;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

// Abstract Strategy class
public abstract class Strategy {
    protected List<Boolean> opponentMoveHistory;
    protected List<Integer> outcomes;

    public Strategy() {
        this.opponentMoveHistory = new ArrayList<>();
        this.outcomes = new ArrayList<>();
    }

    public abstract boolean makeMove();

    public String getStrategyName() {
        return this.getClass().getSimpleName();
    }

    public void addOpponentMove(boolean opponentMove) {
        this.opponentMoveHistory.add(opponentMove);
    }

    public int getPoints() {
        return this.outcomes.stream().reduce(0, (a, b) -> a + b);
    }

    public void clearStrategy() {
        this.outcomes.clear();
        this.opponentMoveHistory.clear();
    }

    public void addOutcome(int outcome) {
        this.outcomes.add(outcome);
    }

    public List<Integer> getOutcomes() {
        return Collections.unmodifiableList(outcomes);
    }
}
