package gametheory;


import gametheory.strategiesImpl.*;

import java.util.*;

public class Tournament {

    private HashMap<Strategy, Integer> points;

    Tournament(List<Strategy> strategies) {
        this.points = new HashMap<>();
        strategies.forEach(s -> this.points.put(s, 0));
    }

    public HashMap<Strategy, Integer> executeTournamentRounds(int numRounds) {
        for (int i = 0; i < numRounds; i++) {
            addNewPoints(tournamentRound(10));
        }
        return this.points;
    }

    private HashMap<Strategy, Integer> tournamentRound(int n) {
        HashMap<Strategy, Integer> tournamentPoints = new HashMap<>();
        Object[] strategies = this.points.keySet().toArray();

        for (int i = 0; i < this.points.keySet().size(); i++) {
            for (int j = i + 1; j < strategies.length; j++) {

                // Ensure Player 1 and Player 2 do not use each other's strategies
                if ((strategies[i] instanceof AlwaysCooperate || strategies[i] instanceof GeneticMemory || strategies[i] instanceof GeneticOneMove) &&
                        (strategies[j] instanceof AlwaysDefect || strategies[j] instanceof GeneticStrategy || strategies[j] instanceof Grudger)) {

                    Game g = new Game((Strategy) strategies[i], (Strategy) strategies[j]);
                    List<Integer> gameOutcome = g.executeGame(n);

                    int s1PrevPts = tournamentPoints.getOrDefault(strategies[i], 0);
                    int s2PrevPts = tournamentPoints.getOrDefault(strategies[j], 0);

                    tournamentPoints.put((Strategy) strategies[i], s1PrevPts + gameOutcome.get(0));
                    tournamentPoints.put((Strategy) strategies[j], s2PrevPts + gameOutcome.get(1));
                } else {
                    System.err.println("Error: Invalid strategy combination! Player 1 cannot use Player 2's strategies and vice versa.");
                }
            }
        }
        return tournamentPoints;
    }

    private void addNewPoints(HashMap<Strategy, Integer> newPoints) {
        for (Strategy s : newPoints.keySet()) {
            int prevPts = this.points.getOrDefault(s, 0);
            this.points.put(s, prevPts + newPoints.get(s));
        }
    }

    public ArrayList<Map.Entry<Strategy, Integer>> sortEntries(Set<Map.Entry<Strategy, Integer>> entrySet) {
        ArrayList<Map.Entry<Strategy, Integer>> sortedEntries = new ArrayList<>(entrySet);
        sortedEntries.sort((e_last, e_now) -> e_now.getValue() - e_last.getValue());

        return sortedEntries;
    }
}

