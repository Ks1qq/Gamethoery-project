package gametheory.strategiesImpl;

import gametheory.Strategy;

public class AlwaysCooperate extends Strategy {
    @Override
    public boolean makeMove() {
        return true; // Always cooperates
    }
}

