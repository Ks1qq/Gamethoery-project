package gametheory.strategiesImpl;
import gametheory.Strategy;

// AlwaysDefect strategy for Player 2
public class AlwaysDefect extends Strategy {
    @Override
    public boolean makeMove() {
        return false; // Always defects
    }
}

