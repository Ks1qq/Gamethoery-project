package gametheory.strategiesImpl;


import gametheory.Strategy;

public class GeneticMemory extends Strategy {
    @Override
    public boolean makeMove() {
        // Implement genetic memory logic here
        return true; // Placeholder logic, will be defined further
    }
}

