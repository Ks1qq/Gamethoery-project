package gametheory.strategiesImpl;


import gametheory.Strategy;

// GeneticOneMove for Player 1
public class GeneticOneMove extends Strategy {
    @Override
    public boolean makeMove() {
        // Implement logic for one move of genetics here
        return true; // Placeholder
    }
}
