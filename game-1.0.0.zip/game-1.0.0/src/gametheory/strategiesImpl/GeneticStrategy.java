package gametheory.strategiesImpl;

import gametheory.Strategy;

import java.util.Random;

// GeneticStrategy for Player 2
public class GeneticStrategy extends Strategy {
    private double weight;

    public GeneticStrategy(double weight) {
        this.weight = weight;
    }

    @Override
    public boolean makeMove() {
        // Placeholder: A strategy based on weight
        return Math.random() < weight;
    }

    public void mutate() {
        Random generator = new Random();
        boolean pm = generator.nextDouble() > 0.5;
        double val = generator.nextDouble() * 0.004;
        weight = pm && weight + val < 1 ? weight + val : weight - val > 0 ? weight - val : weight;
    }

    public GeneticStrategy mutateNew() {
        return new GeneticStrategy(weight);
    }

    public double getWeight() {
        return this.weight;
    }
}