package gametheory.strategiesImpl;

import gametheory.Strategy;

// Grudger for Player 2
public class Grudger extends Strategy {
    private boolean opponentBetrayed = false;

    @Override
    public boolean makeMove() {
        // Implement logic for Grudger strategy here
        return !opponentBetrayed; // Placeholder
    }
}

