package gametheory.strategiesImpl;


import gametheory.Strategy;

import java.util.Random;

public class Simpleton extends Strategy {

    private Random random;

    public Simpleton() {
        random = new Random();
    }

    @Override
    public boolean makeMove() {
        return random.nextBoolean();  // Randomly cooperate or defect
    }
}
